# Copy folder project paste in your project.

# add module app.project in index.module

# include project-style.css inside index.html

# bower install angular-charts-js#0.8.8 in your project.

# include index.html
	<script src="bower_components/Chart.js/Chart.js"></script>
	<script src="bower_components/angular-chart.js/dist/angular-chart.js"></script>
	
# dependency injection 'chart.js' in folder core > core.module.js

# Enjoy :)